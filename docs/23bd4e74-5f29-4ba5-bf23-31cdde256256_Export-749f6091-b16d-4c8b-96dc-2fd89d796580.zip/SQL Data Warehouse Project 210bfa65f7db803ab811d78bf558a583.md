# SQL Data Warehouse Project

👋 Hey, I’m Deepak

I’ve been Learning SQL and Data Warehouse projects for over past months - want work in global companies like MNCs ****to deliver real impact with data.

This roadmap is built entirely from **real-world experience** - not theory - by Baraa
In my work, I’ve used a variety of SQL tools across different projects - including MySQL and SQL Server, which is widely used across industries for  understand how things work behind the scenes in SQL and driving data insights.

Explore recommended full content here [▶️ YouTube Channel](http://bit.ly/3GiCVUE) | [🎓 Udemy Courses](https://www.udemy.com/user/baraa-khatib-salkini-2/) | [💼 LinkedIn Profile](https://www.linkedin.com/in/baraa-khatib-salkini/) | [📰 Newsletter](https://bit.ly/BaraaNewsletter)

[Dwh Project](Dwh%20Project%20210bfa65f7db8189b5b1d0cb7ecb2aa0.csv)

[DWH Tasks](DWH%20Tasks%20210bfa65f7db81058eeacb489dc0a21a.csv)