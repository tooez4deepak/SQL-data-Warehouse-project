# Analysing: Explore & Understand Data

Epics: Build Silver Layer (Build%20Silver%20Layer%20210bfa65f7db8188ad59de24e4527d28.md)
Status: Yes