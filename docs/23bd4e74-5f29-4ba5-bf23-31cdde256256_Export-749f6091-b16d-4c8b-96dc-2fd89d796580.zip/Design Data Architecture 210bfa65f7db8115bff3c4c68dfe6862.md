# Design Data Architecture

Epics: 2
My Progress: 1
Tasks: Design the Layers (Design%20the%20Layers%20210bfa65f7db816492d9ff62a0c9c6ab.md), Draw the Data Architecture (Draw.io) (Draw%20the%20Data%20Architecture%20(Draw%20io)%20210bfa65f7db8135b61ff1022a9b08dc.md), Choose Data Management Approach (Choose%20Data%20Management%20Approach%20210bfa65f7db8165866dcb2e27ef018b.md)