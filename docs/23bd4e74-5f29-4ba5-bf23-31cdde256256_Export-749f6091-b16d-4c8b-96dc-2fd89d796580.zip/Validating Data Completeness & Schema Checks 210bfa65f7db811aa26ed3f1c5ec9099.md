# Validating: Data Completeness & Schema Checks

Epics: Build Bronze Layer (Build%20Bronze%20Layer%20210bfa65f7db81189141e7f243d78439.md)
Status: Yes