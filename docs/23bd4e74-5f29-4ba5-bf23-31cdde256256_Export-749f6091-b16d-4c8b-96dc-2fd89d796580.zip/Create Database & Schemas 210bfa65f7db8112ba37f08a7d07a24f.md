# Create Database & Schemas

Epics: Project Initialization (Project%20Initialization%20210bfa65f7db812fbe45c08098de659e.md)
Status: Yes