# Choose Data Management Approach

Epics: Design Data Architecture (Design%20Data%20Architecture%20210bfa65f7db8115bff3c4c68dfe6862.md)
Status: Yes