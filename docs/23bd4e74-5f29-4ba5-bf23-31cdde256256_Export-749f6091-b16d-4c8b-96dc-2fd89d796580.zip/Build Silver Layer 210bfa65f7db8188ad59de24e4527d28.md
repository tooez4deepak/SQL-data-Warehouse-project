# Build Silver Layer

Epics: 5
My Progress: 1
Tasks: Analysing: Explore & Understand Data (Analysing%20Explore%20&%20Understand%20Data%20210bfa65f7db811291e6e1c06d603eef.md), Document: Draw Data Integration (Draw.io) (Document%20Draw%20Data%20Integration%20(Draw%20io)%20210bfa65f7db814bade1e22e71b0e127.md), Validating: Data Correctness Checks (Validating%20Data%20Correctness%20Checks%20210bfa65f7db8119925ecc63692b582a.md), Document: Extend Data Flow (Draw.io) (Document%20Extend%20Data%20Flow%20(Draw%20io)%20210bfa65f7db817e8984e239754708d6.md), Commit Code in Git Repo (Commit%20Code%20in%20Git%20Repo%20210bfa65f7db819ba12ff48478385810.md), Coding: Data Cleansing (Coding%20Data%20Cleansing%20210bfa65f7db8159892dd8987d4954ba.md)