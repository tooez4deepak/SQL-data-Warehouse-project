# Document: Draw Data Model of Star Schema (Draw.io)

Epics: Build Gold Layer (Build%20Gold%20Layer%20210bfa65f7db81b0a369f688eb310bed.md)
Status: Yes