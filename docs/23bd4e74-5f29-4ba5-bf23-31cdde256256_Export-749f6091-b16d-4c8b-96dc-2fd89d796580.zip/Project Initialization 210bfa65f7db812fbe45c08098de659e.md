# Project Initialization

Epics: 3
My Progress: 1
Tasks: Create Git Repo & Prepare The Repo Structure (Create%20Git%20Repo%20&%20Prepare%20The%20Repo%20Structure%20210bfa65f7db814dbcb2f25a138779a6.md), Create Database & Schemas (Create%20Database%20&%20Schemas%20210bfa65f7db8112ba37f08a7d07a24f.md), Create Detailed Project Tasks (Notion) (Create%20Detailed%20Project%20Tasks%20(Notion)%20210bfa65f7db818081c0f065dd1e3b37.md), Define Project Naming Conventions (Define%20Project%20Naming%20Conventions%20210bfa65f7db81a3ab6fc50b01e056dd.md)