# Build Bronze Layer

Epics: 4
My Progress: 1
Tasks: Analysing: Source Systems (Analysing%20Source%20Systems%20210bfa65f7db81418499ebb8d6770739.md), Coding: Data Ingestion (Coding%20Data%20Ingestion%20210bfa65f7db816592eec3e73079d17d.md), Validating: Data Completeness & Schema Checks (Validating%20Data%20Completeness%20&%20Schema%20Checks%20210bfa65f7db811aa26ed3f1c5ec9099.md), Document: Draw Data Flow (Draw.io) (Document%20Draw%20Data%20Flow%20(Draw%20io)%20210bfa65f7db81259422dc9c1c7d1502.md), Commit Code in Git Repo (Commit%20Code%20in%20Git%20Repo%20210bfa65f7db8188a1afff24b282783b.md)